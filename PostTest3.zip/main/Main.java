package com.mycompany.posttest1.main;

import com.mycompany.posttest1.service.Service;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Service service = new Service(in);

        service.seedAwal();

        while (true) {
            tampilkanMenu();
            System.out.print("Pilih menu [1-6] : ");
            String pilih = in.nextLine().trim();

            if (pilih.equals("1")) {
                service.tambahBarang();
            } else if (pilih.equals("2")) {
                service.tampilkanSemua();
            } else if (pilih.equals("3")) {
                service.perbaruiBarang();
            } else if (pilih.equals("4")) {
                service.hapusBarang();
            } else if (pilih.equals("5")) {
                service.cariBarang();
            } else if (pilih.equals("6")) {
                System.out.print("Apakah yakin kamu ingin keluar? (y/n) : ");
                String konfirmasi = in.nextLine().trim().toLowerCase();
                if (konfirmasi.equals("y")) {
                    System.out.println("\n");
                    System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                    System.out.println("  Terima kasih Telah Menggunakan Program AntikAesthetic!! ");
                    System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                    break;
                } else {
                    System.out.println("\n<<<<< Kembali ke menu utama AntikAesthetic >>>>>");
                }
            } else {
                System.out.println("Pilihan tidak valid.");
            }

            service.enterUntukLanjut();
        }

        in.close();
    }

    // MENU (menjaga teks 100% sama)
    private static void tampilkanMenu() {
        System.out.println("\n===============================================================");
        System.out.println("||          ^^ SELAMAT DATANG DI AntikAesthetic ^^           ||");
        System.out.println("===============================================================");
        System.out.println("------------------------- MENU UTAMA --------------------------");
        System.out.println("||  1. Tambah Barang                                         ||");
        System.out.println("||  2. Tampilkan Semua Barang                                ||");
        System.out.println("||  3. Perbarui Barang (berdasarkan ID)                      ||");
        System.out.println("||  4. Hapus Barang (berdasarkan ID)                         ||");
        System.out.println("||  5. Cari Barang (nama/kategori/asal)                      ||");
        System.out.println("||  6. Keluar                                                ||");
        System.out.println("===============================================================");
    }
}