package com.mycompany.posttest1.service;

import com.mycompany.posttest1.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Iterator;

public class Service {
    private final Scanner in;
    private final List<Barang> koleksi = new ArrayList<>();
    private int nextId = 1;

    public Service(Scanner in) {
        this.in = in;
    }

    // ------- Data awal (campur 2 subclass) -------
    public void seedAwal() {
        koleksi.add(new barangLelang(nextId++, "Vas Dinasti Ming", "Keramik", "Tiongkok", 1560,
                "Porselen", "Baik", "Lelang", 120_000_000));
        koleksi.add(new barangWarisan(nextId++, "Koin Perak VOC", "Koin", "Nusantara", 1750,
                "Perak", "Sedang", "Warisan", 8_500_000));
        koleksi.add(new Barang(nextId++, "Meja Ukir Jepara", "Mebel", "Jepara", 1800,
                "Kayu Jati", "Baik", "Hibah", 55_000_000));
    }

    // ------- Tambah -------
    public void tambahBarang() {
        System.out.println("\n=== Tambah Barang ===");
        System.out.print("Nama            : "); String nama = in.nextLine().trim();
        System.out.print("Kategori        : "); String kategori = in.nextLine().trim();
        System.out.print("Asal            : "); String asal = in.nextLine().trim();
        System.out.print("Tahun           : "); int tahun = parseIntSafe(in.nextLine());
        System.out.print("Material        : "); String material = in.nextLine().trim();
        System.out.print("Kondisi         : "); String kondisi = in.nextLine().trim();
        System.out.print("Sumber (Lelang/Warisan/Hibah/dll) : "); String sumber = in.nextLine().trim();
        System.out.print("Harga Perolehan : "); double harga = parseDoubleSafe(in.nextLine());

        Barang b;
        if (sumber.equalsIgnoreCase("Lelang")) {
            b = new barangLelang(nextId++, nama, kategori, asal, tahun, material, kondisi, sumber, harga);
        } else if (sumber.equalsIgnoreCase("Warisan")) {
            b = new barangWarisan(nextId++, nama, kategori, asal, tahun, material, kondisi, sumber, harga);
        } else {
            b = new Barang(nextId++, nama, kategori, asal, tahun, material, kondisi, sumber, harga);
        }
        koleksi.add(b);
        System.out.println(">> Barang berhasil ditambahkan dengan ID: " + b.getId());
    }

    // ------- Tampilkan semua (polimorfisme: panggil infoSingkat()) -------
    public void tampilkanSemua() {
        System.out.println("\n=== Daftar Barang ===");
        if (koleksi.isEmpty()) {
            System.out.println("Belum ada data.");
            return;
        }
        for (Barang b : koleksi) {
            System.out.println(b.infoSingkat());
        }
    }

    // ------- Perbarui -------
    public void perbaruiBarang() {
        System.out.print("\nMasukkan ID yang diperbarui: ");
        int id = parseIntSafe(in.nextLine());
        Barang b = cariById(id);
        if (b == null) {
            System.out.println("ID tidak ditemukan.");
            return;
        }

        System.out.println("Kosongkan input untuk skip / tidak mengubah.");
        System.out.print("Nama baru            : "); String nama = in.nextLine().trim();
        if (!nama.isEmpty()) b.setNama(nama);

        System.out.print("Kategori baru        : "); String kategori = in.nextLine().trim();
        if (!kategori.isEmpty()) b.setKategori(kategori);

        System.out.print("Asal baru            : "); String asal = in.nextLine().trim();
        if (!asal.isEmpty()) b.setAsal(asal);

        System.out.print("Tahun baru           : "); String sTahun = in.nextLine().trim();
        if (!sTahun.isEmpty()) b.setTahun(parseIntSafe(sTahun));

        System.out.print("Material baru        : "); String material = in.nextLine().trim();
        if (!material.isEmpty()) b.setMaterial(material);

        System.out.print("Kondisi baru         : "); String kondisi = in.nextLine().trim();
        if (!kondisi.isEmpty()) b.setKondisi(kondisi);

        System.out.print("Sumber baru          : "); String sumber = in.nextLine().trim();
        if (!sumber.isEmpty()) b.setSumber(sumber);

        System.out.print("Harga Perolehan baru : "); String sHarga = in.nextLine().trim();
        if (!sHarga.isEmpty()) b.setHargaPerolehan(parseDoubleSafe(sHarga));

        System.out.println(">> Data berhasil diperbarui.");
    }

    // ------- Hapus -------
    public void hapusBarang() {
        System.out.print("\nMasukkan ID yang dihapus: ");
        int id = parseIntSafe(in.nextLine());
        Iterator<Barang> it = koleksi.iterator();
        while (it.hasNext()) {
            if (it.next().getId() == id) {
                it.remove();
                System.out.println(">> Data berhasil dihapus.");
                return;
            }
        }
        System.out.println("ID tidak ditemukan.");
    }

    // ------- Cari (nama/kategori/asal) -------
    public void cariBarang() {
        System.out.print("\nKata kunci (nama/kategori/asal): ");
        String q = in.nextLine().trim().toLowerCase();

        List<Barang> hasil = new ArrayList<>();
        for (Barang b : koleksi) {
            if (b.getNama().toLowerCase().contains(q) ||
                b.getKategori().toLowerCase().contains(q) ||
                b.getAsal().toLowerCase().contains(q)) {
                hasil.add(b);
            }
        }

        if (hasil.isEmpty()) {
            System.out.println("Tidak ada yang cocok.");
        } else {
            System.out.println("=== Hasil Pencarian ===");
            for (Barang b : hasil) {
                System.out.println(b.infoSingkat());
            }
        }
    }

    public void enterUntukLanjut() {
        System.out.print("\nTekan ENTER untuk lanjut...");
        in.nextLine();
    }

    private Barang cariById(int id) {
        for (Barang b : koleksi) if (b.getId() == id) return b;
        return null;
    }

    private int parseIntSafe(String s) {
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return 0; }
    }

    private double parseDoubleSafe(String s) {
        try { return Double.parseDouble(s.trim().replace("_","")); } catch (NumberFormatException e) { return 0.0; }
    }
}