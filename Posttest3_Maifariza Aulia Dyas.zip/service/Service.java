package com.mycompany.posttest1.service;

import com.mycompany.posttest1.model.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Service {
    private final Scanner in;
    private final List<Barang> koleksi = new ArrayList<>();
    private int nextId = 1;

    // ==================== Constructor ===================
    public Service(Scanner in) {
        this.in = in;
    }

    // =================== Seed Data ===================
    public void seedAwal() {
        koleksi.add(new barangLelang(nextId++, "Vas Dinasti Ming", "Keramik", "Tiongkok", 1560,
                "Porselen", "Baik", "Lelang", 120_000_000));
        koleksi.add(new barangWarisan(nextId++, "Koin Perak VOC", "Koin", "Nusantara", 1750,
                "Perak", "Sedang", "Warisan", 8_500_000));
        koleksi.add(new Barang(nextId++, "Meja Ukir Jepara", "Mebel", "Jepara", 1800,
                "Kayu Jati", "Baik", "Hibah", 55_000_000));
        koleksi.add(new barangLelang(nextId++, "Naskah Sansekerta", "Naskah", "India", 1200,
                "Lontar", "Sedang", "Lelang", 200_000_000));
        koleksi.add(new barangWarisan(nextId++, "Guci Dinasti Qing", "Keramik", "Tiongkok", 1700,
                "Porselen", "Baik", "Warisan", 150_000_000));
        koleksi.add(new Barang(nextId++, "Samurai Katana", "Senjata", "Jepang", 1600,
                "Baja", "Baik", "Hibah", 250_000_000));
        koleksi.add(new barangLelang(nextId++, "Kalung Eropa Abad 18", "Perhiasan", "Prancis", 1780,
                "Emas", "Baik", "Lelang", 95_000_000));
        koleksi.add(new Barang(nextId++, "Jam Saku Victoria", "Jam", "Inggris", 1900,
                "Perak", "Sedang", "Pembelian", 22_000_000));
        koleksi.add(new barangWarisan(nextId++, "Piring Kuno Belanda", "Keramik", "Belanda", 1745,
                "Keramik", "Rusak", "Warisan", 15_000_000));
        koleksi.add(new Barang(nextId++, "Kalung Manik-Manik", "Perhiasan", "Kalimantan", 1600,
                "Batu Alam", "Baik", "Hibah", 18_000_000));
        koleksi.add(new barangLelang(nextId++, "Cincin Batu Safir", "Perhiasan", "Sri Lanka", 1500,
                "Batu Safir", "Baik", "Lelang", 120_000_000));
        koleksi.add(new Barang(nextId++, "Topeng Kayu Jawa", "Topeng", "Jawa", 1850,
                "Kayu", "Baik", "Pembelian", 10_000_000));
        koleksi.add(new barangWarisan(nextId++, "Patung Buddha Kuno", "Patung", "India", 1420,
                "Perunggu", "Baik", "Warisan", 45_000_000));
        koleksi.add(new Barang(nextId++, "Lukisan Wayang Beber", "Lukisan", "Jawa", 1650,
                "Kain", "Baik", "Pembelian", 65_000_000));
        koleksi.add(new barangLelang(nextId++, "Keris Pusaka", "Senjata", "Jawa", 1750,
                "Besi", "Baik", "Lelang", 35_000_000));
        koleksi.add(new Barang(nextId++, "Pedang Shamsir", "Senjata", "Persia", 1600,
                "Baja", "Baik", "Pembelian", 210_000_000));
        koleksi.add(new barangWarisan(nextId++, "Keramik Dinasti Song", "Keramik", "Tiongkok", 1100,
                "Porselen", "Sedang", "Warisan", 90_000_000));
        koleksi.add(new Barang(nextId++, "Kalung Emas Mesir", "Perhiasan", "Mesir", 1300,
                "Emas", "Baik", "Pembelian", 500_000_000));
        koleksi.add(new barangLelang(nextId++, "Topeng Barong Bali", "Topeng", "Bali", 1800,
                "Kayu Jati", "Baik", "Lelang", 75_000_000));
        koleksi.add(new Barang(nextId++, "Patung Ganesha", "Patung", "Jawa Tengah", 1350,
                "Batu Andesit", "Baik", "Hibah", 225_000_000));
    }

    // =================== Tampilkan Barang ===================
    public void tampilkanTabelBarang(boolean showFooter) {
        System.out.println("\n+----+----------------------+--------------+--------------+-------+--------------+-----------+-----------+------------------+");
        System.out.println("| ID | Nama                 | Kategori     | Asal         | Tahun | Material     | Kondisi   | Sumber    | Harga            |");
        System.out.println("+----+----------------------+--------------+--------------+-------+--------------+-----------+-----------+------------------+");

        if (koleksi.isEmpty()) {
            System.out.printf("| %-110s |\n", "Belum ada data barang");
        } else {
            for (Barang b : koleksi) {
                System.out.printf("| %-2d | %-20s | %-12s | %-12s | %-5d | %-12s | %-9s | %-9s | Rp. %-12.0f |\n",
                        b.getId(),
                        b.getNama(),
                        b.getKategori(),
                        b.getAsal(),
                        b.getTahun(),
                        b.getMaterial(),
                        b.getKondisi(),
                        b.getSumber(),
                        b.getHargaPerolehan()
                );
            }
        }

        System.out.println("+----+----------------------+--------------+--------------+-------+--------------+-----------+-----------+------------------+");
        if (showFooter) {
            System.out.println("~~~ Tekan Enter untuk melanjutkan..");
        }
    }

    public void tampilkanSemua() {
        tampilkanTabelBarang(true);
    }

    // ======================= CRUD ========================
    public void tambahBarang() {
        System.out.println("\n.......................................................");
        System.out.println("             TAMBAH BARANG AntikAesthetic             ");
        System.out.println(".......................................................");

        String nama     = inputString("Nama");
        String kategori = inputString("Kategori");
        String asal     = inputString("Asal");
        int tahun       = inputInt("Tahun", 0, 3000);
        String material = inputString("Material");
        String kondisi  = inputString("Kondisi");
        String sumber   = inputString("Sumber (Lelang/Warisan/Hibah/dll)");
        double harga    = inputDouble("Harga Perolehan", 0, Double.MAX_VALUE);

        Barang b;
        if (sumber.equalsIgnoreCase("Lelang")) {
            b = new barangLelang(nextId++, nama, kategori, asal, tahun, material, kondisi, sumber, harga);
        } else if (sumber.equalsIgnoreCase("Warisan")) {
            b = new barangWarisan(nextId++, nama, kategori, asal, tahun, material, kondisi, sumber, harga);
        } else {
            b = new Barang(nextId++, nama, kategori, asal, tahun, material, kondisi, sumber, harga);
        }
        koleksi.add(b);
        System.out.println(">> Barang berhasil ditambahkan dengan ID: " + b.getId());
    }

    public void perbaruiBarang() {
        System.out.println("...........................................................................................................................");
        System.out.println("                                               PERBARUI BARANG AntikAesthetic                                              ");
        System.out.println("-------------------------------------------------- Cari Berdasarkan ID ----------------------------------------------------");
        System.out.println("...........................................................................................................................");
        tampilkanTabelBarang(false);
        System.out.print("\nMasukkan ID yang diperbarui: ");
        int id = parseIntSafe(in.nextLine());
        Barang b = cariById(id);
        if (b == null) {
            System.out.println("ID tidak ditemukan.");
            return;
        }

        System.out.println("Kosongkan input untuk melewati (tidak mengubah).");
        System.out.println("=================================================");
        b.setNama(            inputStringOpsional("Nama baru", b.getNama()));
        b.setKategori(        inputStringOpsional("Kategori baru", b.getKategori()));
        b.setAsal(            inputStringOpsional("Asal baru", b.getAsal()));
        b.setTahun(           inputIntOpsional("Tahun baru", b.getTahun(), 0, 3000));
        b.setMaterial(        inputStringOpsional("Material baru", b.getMaterial()));
        b.setKondisi(         inputStringOpsional("Kondisi baru", b.getKondisi()));
        b.setSumber(          inputStringOpsional("Sumber baru", b.getSumber()));
        b.setHargaPerolehan(  inputDoubleOpsional("Harga Perolehan baru", b.getHargaPerolehan(), 0, Double.MAX_VALUE));

        System.out.println("........ Data berhasil diperbarui ........");
    }

    public void hapusBarang() {
        System.out.println();
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        System.out.println("                                               HAPUS BARANG AntikAesthetic                                              ");
        System.out.println("-------------------------------------------------- Cari Berdasarkan ID ----------------------------------------------------");
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        tampilkanTabelBarang(false);

        Integer id = null;
        while (true) {
            System.out.print("Masukkan ID yang akan dihapus : ");
            String s = in.nextLine().trim();

            if (s.isEmpty()) {
                System.out.println("Input tidak boleh kosong.");
                continue;
            }

            try {
                id = Integer.valueOf(s);
            } catch (NumberFormatException e) {
                System.out.println("Oops... Harus berupa angka.");
                continue;
            }

            Barang targetCek = cariById(id);
            if (targetCek == null) {
                System.out.println("Data dengan ID " + id + " tidak ditemukan.");
                continue;
            }
            break;
        }

        System.out.print("Yakin hapus ID " + id + " (y/n)? ");
        String ans = in.nextLine().trim().toLowerCase();
        if (ans.equals("y")) {
            Iterator<Barang> it = koleksi.iterator();
            while (it.hasNext()) {
                if (it.next().getId() == id) {
                    it.remove();
                    System.out.println("~~~~~~~ Data ID " + id + " telah dihapus ~~~~~~~");
                    break;
                }
            }
        } else {
            System.out.println(">>>>> Dibatalkan <<<<<");
        }
    }

    public void cariBarang() {
        System.out.println("\n========================================================");
        System.out.println("                 CARI BARANG AntikAesthetic             ");
        System.out.println("========================================================");

        String key = inputString("Kata kunci").toLowerCase();

        List<Barang> hasil = new ArrayList<>();
        for (Barang b : koleksi) {
            if (b.getNama().toLowerCase().contains(key)
                    || b.getKategori().toLowerCase().contains(key)
                    || b.getAsal().toLowerCase().contains(key)) {
                hasil.add(b);
            }
        }

        if (hasil.isEmpty()) {
            System.out.println("Oops.. Tidak ada hasil untuk: " + key);
            return;
        }

        System.out.println("\n+----+----------------------+--------------+--------------+-------+--------------+-----------+-----------+------------------+");
        System.out.println("| ID | Nama                 | Kategori     | Asal         | Tahun | Material     | Kondisi   | Sumber    | Harga            |");
        System.out.println("+----+----------------------+--------------+--------------+-------+--------------+-----------+-----------+------------------+");

        for (Barang b : hasil) {
            System.out.printf("| %-2d | %-20s | %-12s | %-12s | %-5d | %-12s | %-9s | %-9s | Rp. %-12.0f |\n",
                    b.getId(),
                    potong(b.getNama(), 20),
                    potong(b.getKategori(), 12),
                    potong(b.getAsal(), 12),
                    b.getTahun(),
                    potong(b.getMaterial(), 12),
                    potong(b.getKondisi(), 9),
                    potong(b.getSumber(), 9),
                    b.getHargaPerolehan());
        }
        
        System.out.println("\n********* RINGKASAN *********");
        for (Barang b : hasil) {
            System.out.println("- " + b.infoSingkat()); // akan [LELANG]/[WARISAN] jika subclass override
        }
    }
    
    private String potong(String s, int maxLen) {
        if (s == null) return "";
        if (s.length() <= maxLen) return s;
        if (maxLen <= 1) return s.substring(0, 1);
        return s.substring(0, maxLen - 1) + "…";
    }

    // ======================= Util =======================
    public void enterUntukLanjut() {
        System.out.print("\nTekan ENTER untuk lanjut...");
        in.nextLine();
    }

    private Barang cariById(int id) {
        for (Barang b : koleksi) if (b.getId() == id) return b;
        return null;
    }

    private int parseIntSafe(String s) {
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return 0; }
    }

    private double parseDoubleSafe(String s) {
        try { return Double.parseDouble(s.trim().replace("_","")); } catch (NumberFormatException e) { return 0.0; }
    }

    private String inputString(String label) {
        while (true) {
            System.out.print(label + " : ");
            String s = in.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Input tidak boleh kosong.");
        }
    }

    private int inputInt(String label, int min, int max) {
        while (true) {
            System.out.print(label + " : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) {
                System.out.println("Input tidak boleh kosong.");
                continue;
            }
            try {
                int val = Integer.parseInt(s);
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + max + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka.");
            }
        }
    }

    private double inputDouble(String label, double min, double max) {
        while (true) {
            System.out.print(label + " : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) {
                System.out.println("Input tidak boleh kosong.");
                continue;
            }
            try {
                double val = Double.parseDouble(s.replace("_", ""));
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + (max == Double.MAX_VALUE ? "tak hingga" : max) + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka (boleh desimal).");
            }
        }
    }

    private String inputStringOpsional(String label, String lama) {
        System.out.print(label + " [" + lama + "] : ");
        String s = in.nextLine().trim();
        return s.isEmpty() ? lama : s;
    }

    private int inputIntOpsional(String label, int lama, int min, int max) {
        while (true) {
            System.out.print(label + " [" + lama + "] : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) return lama;
            try {
                int val = Integer.parseInt(s);
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + max + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka.");
            }
        }
    }

    private double inputDoubleOpsional(String label, double lama, double min, double max) {
        while (true) {
            System.out.print(label + " [Rp" + String.format("%,.0f", lama) + "] : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) return lama;
            try {
                double val = Double.parseDouble(s.replace("_", ""));
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + (max == Double.MAX_VALUE ? "tak hingga" : max) + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka (boleh desimal).");
            }
        }
    }
}