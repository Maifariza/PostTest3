package com.mycompany.posttest1.model;

public class barangWarisan extends Barang {
    public barangWarisan(int id, String nama, String kategori, String asal, int tahun,
                         String material, String kondisi, String sumber, double hargaPerolehan) {
        super(id, nama, kategori, asal, tahun, material, kondisi, sumber, hargaPerolehan);
    }

    @Override
    public String infoSingkat() {
        return super.infoSingkat() + " | tipe: WARISAN";
    }
}
